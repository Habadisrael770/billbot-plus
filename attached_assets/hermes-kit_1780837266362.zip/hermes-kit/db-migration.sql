-- Hermes Starter Kit — Database Migration
-- Run this once against your PostgreSQL database.
-- Compatible with any PostgreSQL 13+ database.

CREATE TABLE IF NOT EXISTS hermes_credits (
  user_id       TEXT        NOT NULL PRIMARY KEY,
  balance       INTEGER     NOT NULL DEFAULT 0,
  total_granted INTEGER     NOT NULL DEFAULT 0,
  total_used    INTEGER     NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hermes_credit_txns (
  id            BIGSERIAL   PRIMARY KEY,
  user_id       TEXT        NOT NULL REFERENCES hermes_credits(user_id),
  delta         INTEGER     NOT NULL,
  reason        TEXT        NOT NULL,
  note          TEXT,
  balance_after INTEGER     NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS hermes_credit_txns_user_id_idx
  ON hermes_credit_txns (user_id, created_at DESC);
