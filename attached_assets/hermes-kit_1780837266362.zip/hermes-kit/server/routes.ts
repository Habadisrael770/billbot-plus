/**
 * Hermes Routes — Hermes Starter Kit
 *
 * How to integrate into your Express app:
 *
 *   import { Pool } from "pg";
 *   import { registerHermesRoutes } from "./hermes-kit/server/routes";
 *
 *   const pool = new Pool({ connectionString: process.env.DATABASE_URL });
 *   registerHermesRoutes(app, pool, (req) => resolveYourUser(req));
 *
 * The `resolveUser` callback must return:
 *   { id: string; isAdmin: boolean } | null
 *
 * Return null to reject the request as unauthorized.
 * Wire this to whatever auth system your app uses (JWT, session, cookie, etc.)
 *
 * ─────────────────────────────────────────────────────────
 * ENV VARS REQUIRED (add to Replit Secrets):
 *   HERMES_BRIDGE_URL    — https://your-bridge.domain.com
 *   HERMES_BRIDGE_TOKEN  — secret bearer token
 * ─────────────────────────────────────────────────────────
 */

import type { Express, Request, Response } from "express";
import type { Pool } from "pg";
import { checkHealth, sendMessage, isHermesConfigured } from "./client";
import { makeCreditsService } from "./credits.service";

// ── ✏️  CUSTOMIZE: Edit your system prompts here ────────────────────────────

function buildSystemPrompt(isAdmin: boolean): string {
  if (isAdmin) {
    // Admins get full access — no topic restrictions
    return `You are Hermes, an AI assistant integrated into [YOUR APP NAME].
Help the administrator with any question about the platform, data, and operations.
Answer in the same language the user writes in.`;
  }

  // Regular users get a scoped prompt — restrict to your app's domain
  return `You are Hermes, an AI assistant integrated into [YOUR APP NAME].
Your ONLY purpose is to help users with questions related to [YOUR APP DOMAIN].

STRICT RULES:
1. REFUSE any question unrelated to [YOUR APP DOMAIN].
2. For off-topic questions respond: "I can only help with questions about [YOUR APP NAME]."
3. Answer in the same language the user writes in.`;
}

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ResolvedUser {
  id: string;
  isAdmin: boolean;
}

export type ResolveUserFn = (req: Request) => Promise<ResolvedUser | null> | ResolvedUser | null;

// ── Route registration ────────────────────────────────────────────────────────

export function registerHermesRoutes(
  app: Express,
  pool: Pool,
  resolveUser: ResolveUserFn,
): void {
  const credits = makeCreditsService(pool);

  // ── Health check ───────────────────────────────────────────────────────────
  app.get("/api/hermes/health", async (_req: Request, res: Response) => {
    if (!isHermesConfigured()) {
      return res.status(503).json({ ok: false, configured: false, error: "Hermes bridge not configured." });
    }
    const result = await checkHealth();
    if (!result.ok) {
      return res.status(result.status >= 400 ? result.status : 502)
        .json({ ok: false, configured: true, error: result.error });
    }
    return res.json({ ok: true, configured: true, hermes: result.data ?? null });
  });

  // ── Get credit balance ─────────────────────────────────────────────────────
  app.get("/api/hermes/credits", async (req: Request, res: Response) => {
    const caller = await resolveUser(req);
    if (!caller) return res.status(401).json({ ok: false, error: "Unauthorized" });

    const balance = await credits.getOrCreateCredits(caller.id, caller.isAdmin);
    const history = await credits.getCreditHistory(caller.id, 20);
    return res.json({ ok: true, balance, history });
  });

  // ── Send message ───────────────────────────────────────────────────────────
  app.post("/api/hermes/message", async (req: Request, res: Response) => {
    if (!isHermesConfigured()) {
      return res.status(503).json({ ok: false, error: "Hermes bridge not configured." });
    }

    const caller = await resolveUser(req);
    if (!caller) return res.status(401).json({ ok: false, error: "Unauthorized" });

    const { message, conversationId } = req.body ?? {};
    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ ok: false, error: "message is required" });
    }
    if (message.length > 4000) {
      return res.status(400).json({ ok: false, error: "message too long (max 4000 chars)" });
    }

    // Credit check
    const balance = await credits.getOrCreateCredits(caller.id, caller.isAdmin);
    if (balance <= 0) {
      return res.status(402).json({ ok: false, error: "no_credits", balance: 0 });
    }

    // Deduct
    const deduct = await credits.deductCredit(caller.id, message.slice(0, 100));
    if (!deduct.ok) {
      return res.status(402).json({ ok: false, error: "no_credits", balance: deduct.balance });
    }

    // Build system-augmented message
    const systemPrompt = buildSystemPrompt(caller.isAdmin);
    const fullMessage = `[SYSTEM INSTRUCTIONS]\n${systemPrompt}\n\n[USER MESSAGE]\n${message.trim()}`;

    const result = await sendMessage({
      message: fullMessage,
      conversationId: typeof conversationId === "string" ? conversationId : undefined,
    });

    if (!result.ok) {
      // Refund on bridge error
      await credits.grantCredits(caller.id, 1, "refund", "bridge_error");
      return res.status(result.status >= 400 ? result.status : 502)
        .json({ ok: false, error: result.error });
    }

    return res.json({
      ok: true,
      reply: (result.data as any)?.reply ?? null,
      balance: deduct.balance,
    });
  });

  // ── Admin: list all credit accounts ───────────────────────────────────────
  app.get("/api/hermes/admin/credits", async (req: Request, res: Response) => {
    const caller = await resolveUser(req);
    if (!caller?.isAdmin) return res.status(403).json({ ok: false, error: "Forbidden" });
    const accounts = await credits.getAllCreditAccounts();
    return res.json({ ok: true, accounts });
  });

  // ── Admin: grant credits to a user ────────────────────────────────────────
  app.post("/api/hermes/admin/credits/:userId/grant", async (req: Request, res: Response) => {
    const caller = await resolveUser(req);
    if (!caller?.isAdmin) return res.status(403).json({ ok: false, error: "Forbidden" });

    const userId = req.params.userId as string;
    const { amount, note } = req.body ?? {};
    if (!amount || typeof amount !== "number" || amount < 1 || amount > 100_000) {
      return res.status(400).json({ ok: false, error: "amount must be 1–100000" });
    }
    const result = await credits.grantCredits(userId, amount, "admin_grant", note ?? `Granted by admin`);
    return res.json(result);
  });
}
