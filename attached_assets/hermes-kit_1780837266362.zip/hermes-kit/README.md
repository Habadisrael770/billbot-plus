# Hermes Starter Kit

Plug-and-play Hermes AI chat integration for any Express + React project.
Each app gets its own independent chat, credit system, and system prompt.
All apps share the same Hermes Bridge running on your VPS.

---

## What's in the kit

```
hermes-kit/
├── server/
│   ├── client.ts           — Bridge HTTP client (copy as-is)
│   ├── routes.ts           — Express API routes (edit system prompt here)
│   └── credits.service.ts  — Credit system with raw pg
├── client/
│   └── hermes-chat.tsx     — Standalone React chat component
├── db-migration.sql        — Run once to create the 2 required tables
├── example-system-prompt.md — Ready-to-use system prompt templates
└── README.md               — This file
```

---

## Integration steps

### 1. Copy files into your project

```bash
# Copy server files
cp hermes-kit/server/client.ts         your-project/server/hermes/client.ts
cp hermes-kit/server/routes.ts         your-project/server/hermes/routes.ts
cp hermes-kit/server/credits.service.ts your-project/server/hermes/credits.service.ts

# Copy client component
cp hermes-kit/client/hermes-chat.tsx   your-project/client/src/pages/hermes-chat.tsx
```

---

### 2. Add Secrets in Replit

Go to your project → **Secrets** tab, and add:

| Secret | Value |
|--------|-------|
| `HERMES_BRIDGE_URL` | `https://hermes.yourdomain.com` |
| `HERMES_BRIDGE_TOKEN` | The secret bearer token from your VPS |

These are the **same values** for every project. The bridge is shared.

---

### 3. Run the database migration

Open your project's shell or database console and run:

```sql
-- Paste contents of hermes-kit/db-migration.sql
CREATE TABLE IF NOT EXISTS hermes_credits ( ... );
CREATE TABLE IF NOT EXISTS hermes_credit_txns ( ... );
```

Or run it programmatically on startup:

```typescript
import fs from "fs";
import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const sql = fs.readFileSync("hermes-kit/db-migration.sql", "utf8");
await pool.query(sql);
```

---

### 4. Register routes in your Express server

```typescript
// server/index.ts (or server/routes.ts)
import { Pool } from "pg";
import { registerHermesRoutes } from "./hermes/routes";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ── Implement resolveUser to match YOUR app's auth ────────────────────────
// Return { id: string; isAdmin: boolean } or null (unauthorized)
async function resolveUser(req: Request) {
  // Example with JWT:
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return null;
  const payload = verifyJwt(token); // your own verify function
  if (!payload) return null;
  return { id: payload.userId, isAdmin: payload.role === "admin" };

  // Example with session:
  // if (!req.session?.userId) return null;
  // return { id: req.session.userId, isAdmin: req.session.isAdmin ?? false };
}

registerHermesRoutes(app, pool, resolveUser);
```

---

### 5. Add the chat page to your React app

```tsx
// client/src/App.tsx
import HermesChat from "./pages/hermes-chat";

// Inside your router:
<Route path="/hermes" component={() => (
  <HermesChat
    authHeader={() => {
      const token = localStorage.getItem("your-auth-token");
      return token ? { Authorization: `Bearer ${token}` } : {};
    }}
    isAdmin={currentUser?.role === "admin"}
    title="Hermes AI"
    subtitle="Your AI assistant"
  />
)} />
```

Or embed it anywhere as a component — it has no layout dependencies.

---

### 6. Customize the system prompt

Open `server/hermes/routes.ts` and edit `buildSystemPrompt()`:

```typescript
function buildSystemPrompt(isAdmin: boolean): string {
  if (isAdmin) {
    return `You are Hermes, integrated into MY APP NAME.
Help the admin with anything about the platform.
Answer in the same language the user writes in.`;
  }
  return `You are Hermes, integrated into MY APP NAME.
Only answer questions about MY APP DOMAIN.
For off-topic questions reply: "I can only help with MY APP NAME questions."
Answer in the same language the user writes in.`;
}
```

See `example-system-prompt.md` for ready-made templates.

---

## Credit system

| User type | Default credits | Credits per message |
|-----------|----------------|---------------------|
| Admin | 999,999 (shown as ∞) | 1 |
| Regular user | 50 | 1 |

Grant more credits via API:
```bash
curl -X POST /api/hermes/admin/credits/<userId>/grant \
  -H "Authorization: Bearer <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{"amount": 100, "note": "Monthly top-up"}'
```

---

## API reference

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/hermes/health` | Public | Bridge liveness check |
| GET | `/api/hermes/credits` | User | Get balance + history |
| POST | `/api/hermes/message` | User | Send a message, get reply |
| GET | `/api/hermes/admin/credits` | Admin | List all user accounts |
| POST | `/api/hermes/admin/credits/:userId/grant` | Admin | Grant credits to a user |

---

## FAQ

**Q: Does each app need its own bridge?**
No. All apps share the same bridge on your VPS. They just need the same `HERMES_BRIDGE_URL` and `HERMES_BRIDGE_TOKEN`.

**Q: Are credits shared between apps?**
No. Each app has its own `hermes_credits` table in its own database.

**Q: What if I don't use pg/node-postgres?**
Rewrite `credits.service.ts` using your ORM (Drizzle, Prisma, Sequelize). The logic is straightforward — see the raw SQL queries inside each function.

**Q: Can I add file export (Excel/PDF) like in B1 LoyaltyOS?**
Yes — add `reports.service.ts` from B1 LoyaltyOS and wire it into the `POST /api/hermes/message` handler. It's a B1-specific feature, not included in this kit.
